/* This file is auto generated, version 51+unity1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#51+unity1 SMP Sat Mar 30 23:36:25 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "dad6412c9042"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
