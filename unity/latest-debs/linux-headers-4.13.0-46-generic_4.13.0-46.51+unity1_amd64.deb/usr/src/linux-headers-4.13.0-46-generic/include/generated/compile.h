/* This file is auto generated, version 51+unity1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#51+unity1 SMP Wed Mar 27 18:14:05 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "812550ce7e52"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
