/* This file is auto generated, version 51+unity1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#51+unity1 SMP Fri Aug 24 18:34:13 UTC 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "435ce7349c5e"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
