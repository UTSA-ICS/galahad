/* This file is auto generated, version 40+unity1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#40+unity1 SMP Fri Mar 9 17:03:13 UTC 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ee5e21f9331b"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-8ubuntu3.2)"
