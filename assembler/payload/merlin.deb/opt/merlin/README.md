To get this Virtue's ID, run: /opt/merlin/get_virtue_id
